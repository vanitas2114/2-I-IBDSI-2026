import json
import xml.etree.ElementTree as ET

from FileManager import FileManager
from User import User

class MainProgram:

    def obj_dict(self,obj):
        return obj.__dict__
    
    def object_to_xml(self, obj):
        root = ET.Element(obj.__class__.__name__)

        ET.SubElement(root, "name").text = str(obj.name)
        ET.SubElement(root, "email").text = str(obj.email)
        ET.SubElement(root, "exam").text = str(obj.exam)
        ET.SubElement(root, "note").text = str(obj.note)
        ET.SubElement(root, "grade").text = str(obj.grade)
        ET.SubElement(root, "group").text = str(obj.group)
        ET.SubElement(root, "shift").text = str(obj.shift)
        print(ET.tostring(root, encoding='unicode'))

    def example(self):
        test = FileManager()
        test.read_entire_file('example.txt', 'r')
        test.get_file_lines('example.txt', 'r')
        test.read_line_by_line('example.txt', 'r')
        #user = User()
    
    def writting_example(self):
        test = FileManager()
        test.write_text('example2.txt', "test text")

    def object_to_json(self, obj):
        json_pretty = json.dumps(obj, default=self.obj_dict, indent=4)
        print(json_pretty)

user_list=[]
user=User(
            "Franco Garcia David Alejandro",
            "david.franco.2025.tmp@mit.edu",
            5,1,2,"I","V")

user_list.append(user)
main = MainProgram()
main.example()
main.writting_example()
main.object_to_json(user_list)
main.object_to_xml(user)        